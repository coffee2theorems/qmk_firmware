//
//  Constants.m
//  QMK Toolbox
//
//  Created by Danny Nguyen on 10/30/17.
//  Copyright © 2017 QMK. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Constants.h"

NSString * const QMKMicrocontrollerKey = @"Microcontroller";
